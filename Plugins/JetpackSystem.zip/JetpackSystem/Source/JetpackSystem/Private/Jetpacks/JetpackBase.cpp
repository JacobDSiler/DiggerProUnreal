#include "Jetpacks/JetpackBase.h"
#include "NiagaraComponent.h"
#include "GameFramework/CharacterMovementComponent.h"

AJetpackBase::AJetpackBase()
{
    PrimaryActorTick.bCanEverTick = true;

    MeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MeshComponent"));
    RootComponent = MeshComponent;

    NiagaraComponent = CreateDefaultSubobject<UNiagaraComponent>(TEXT("NiagaraComponent"));
    NiagaraComponent->SetupAttachment(RootComponent);
    NiagaraComponent->bAutoActivate = false;

    bIsThrusting = false;
    bIsDepleted = false;
}

void AJetpackBase::InitializeJetpack(ACharacter *InOwnerChar, UJetpackDataAsset *InData)
{
    OwningCharacter = InOwnerChar;
    JetpackData = InData;

    if (JetpackData)
    {
        CurrentFuel = JetpackData->MaxFuel;
        if (JetpackData->ExhaustVFX)
        {
            NiagaraComponent->SetAsset(JetpackData->ExhaustVFX);
        }
    }
}

void AJetpackBase::StartThrust()
{
    if (bIsDepleted || !OwningCharacter)
        return;
    bIsThrusting = true;
    ActivateVFX();
}

void AJetpackBase::StopThrust()
{
    bIsThrusting = false;
    DeactivateVFX();
}

void AJetpackBase::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    if (bIsThrusting && !bIsDepleted)
    {
        ConsumeFuel(DeltaTime);
        ApplyThrust(DeltaTime);
    }
}

void AJetpackBase::ConsumeFuel(float DeltaTime)
{
    if (!JetpackData)
        return;

    CurrentFuel -= JetpackData->FuelConsumptionRate * DeltaTime;

    if (CurrentFuel <= 0.0f)
    {
        CurrentFuel = 0.0f;
        bIsDepleted = true;
        StopThrust(); // Force stop
    }
}

void AJetpackBase::ApplyThrust(float DeltaTime)
{
    if (OwningCharacter)
    {
        // Standard Vertical Thrust
        FVector LaunchVelocity = FVector::UpVector * JetpackData->ThrustStrength * DeltaTime;
        OwningCharacter->LaunchCharacter(LaunchVelocity, false, false);
    }
}

void AJetpackBase::ActivateVFX()
{
    if (NiagaraComponent)
        NiagaraComponent->Activate();
}

void AJetpackBase::DeactivateVFX()
{
    if (NiagaraComponent)
        NiagaraComponent->Deactivate();
}