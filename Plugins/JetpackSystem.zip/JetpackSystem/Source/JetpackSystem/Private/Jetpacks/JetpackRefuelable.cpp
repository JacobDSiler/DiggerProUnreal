#include "Jetpacks/JetpackRefuelable.h"

void AJetpackRefuelable::StopThrust()
{
    Super::StopThrust();
    LastThrustTime = GetWorld()->GetTimeSeconds();
}

void AJetpackRefuelable::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    // Recharge logic
    if (!bIsThrusting && JetpackData && CurrentFuel < JetpackData->MaxFuel)
    {
        if (GetWorld()->GetTimeSeconds() - LastThrustTime >= JetpackData->RefuelDelay)
        {
            CurrentFuel += JetpackData->RefuelRate * DeltaTime;
            CurrentFuel = FMath::Min(CurrentFuel, JetpackData->MaxFuel);
            bIsDepleted = false; // Reactivate if we gained fuel
        }
    }
}