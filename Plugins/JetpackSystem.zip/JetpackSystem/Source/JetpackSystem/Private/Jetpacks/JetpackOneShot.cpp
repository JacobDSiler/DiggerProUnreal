#include "Jetpacks/JetpackOneShot.h"
#include "GameFramework/CharacterMovementComponent.h"

void AJetpackOneShot::StartThrust()
{
    if (bIsDepleted || !OwningCharacter)
        return;

    Super::StartThrust();

    if (UCharacterMovementComponent *CMC = OwningCharacter->GetCharacterMovement())
    {
        // Cache old value
        OriginalAirControl = CMC->AirControl;

        // Set Requirements: Falling Mode and 0 Air Control
        CMC->SetMovementMode(MOVE_Falling);
        CMC->AirControl = 0.0f;
    }
}

void AJetpackOneShot::StopThrust()
{
    Super::StopThrust();

    // Restore control when stopped (or depleted)
    if (OwningCharacter)
    {
        if (UCharacterMovementComponent *CMC = OwningCharacter->GetCharacterMovement())
        {
            CMC->AirControl = OriginalAirControl;
        }
    }
}

void AJetpackOneShot::ApplyThrust(float DeltaTime)
{
    if (OwningCharacter)
    {
        // Constant Forward Impulse (Force over time)
        FVector ForwardDir = OwningCharacter->GetActorForwardVector();
        // Using AddForce for continuous "Impulse" feel over frames
        if (UCharacterMovementComponent *CMC = OwningCharacter->GetCharacterMovement())
        {
            CMC->AddForce(ForwardDir * JetpackData->ThrustStrength * 100.0f); // Scale up for Force
        }
    }
}