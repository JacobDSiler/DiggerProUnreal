#include "JetpackComponent.h"
#include "GameFramework/Character.h"

UJetpackComponent::UJetpackComponent()
{
    PrimaryComponentTick.bCanEverTick = false; // Component doesn't tick, the Actor does
}

void UJetpackComponent::BeginPlay()
{
    Super::BeginPlay();

    // Auto-equip if defaults are set
    if (DefaultJetpackClass && DefaultJetpackData)
    {
        EquipJetpack(DefaultJetpackClass, DefaultJetpackData);
    }
}

void UJetpackComponent::EquipJetpack(TSubclassOf<AJetpackBase> JetpackClass, UJetpackDataAsset *Data)
{
    if (CurrentJetpackActor)
    {
        UnequipJetpack();
    }

    if (!JetpackClass || !Data)
        return;

    ACharacter *CharacterOwner = Cast<ACharacter>(GetOwner());
    if (!CharacterOwner)
        return;

    FActorSpawnParameters SpawnParams;
    SpawnParams.Owner = CharacterOwner;
    SpawnParams.Instigator = CharacterOwner;

    CurrentJetpackActor = GetWorld()->SpawnActor<AJetpackBase>(JetpackClass, CharacterOwner->GetActorTransform(), SpawnParams);

    if (CurrentJetpackActor)
    {
        // Attach to character mesh
        CurrentJetpackActor->AttachToComponent(
            CharacterOwner->GetMesh(),
            FAttachmentTransformRules::SnapToTargetNotIncludingScale,
            CharacterSocketName);

        CurrentJetpackActor->InitializeJetpack(CharacterOwner, Data);
    }
}

void UJetpackComponent::UnequipJetpack()
{
    if (CurrentJetpackActor)
    {
        CurrentJetpackActor->Destroy();
        CurrentJetpackActor = nullptr;
    }
}

void UJetpackComponent::StartJetpack()
{
    if (CurrentJetpackActor)
    {
        CurrentJetpackActor->StartThrust();
    }
}

void UJetpackComponent::StopJetpack()
{
    if (CurrentJetpackActor)
    {
        CurrentJetpackActor->StopThrust();
    }
}

float UJetpackComponent::GetCurrentFuelPercent() const
{
    // Need a getter in Base class, or make CurrentFuel public (it is protected in this example)
    // Assuming we add GetCurrentFuel() to AJetpackBase
    return 0.0f; // Placeholder implementation
}