/*using UnrealBuildTool;

public class JetpackSystem : ModuleRules
{
    public JetpackSystem(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(
            new string[]
            {
                "Core",
                "CoreUObject",
                "Engine",
                "InputCore",
                "Niagara", // Required for VFX
                "PhysicsCore"
            }
        );
    }
}*/