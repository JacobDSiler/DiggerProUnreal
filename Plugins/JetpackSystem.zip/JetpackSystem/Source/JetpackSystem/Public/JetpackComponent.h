#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "JetpackDataAsset.h"
#include "Jetpacks/JetpackBase.h"
#include "JetpackComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class JETPACKSYSTEM_API UJetpackComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UJetpackComponent();

    // -- Blueprint API --

    UFUNCTION(BlueprintCallable, Category = "Jetpack")
    void EquipJetpack(TSubclassOf<AJetpackBase> JetpackClass, UJetpackDataAsset *Data);

    UFUNCTION(BlueprintCallable, Category = "Jetpack")
    void UnequipJetpack();

    UFUNCTION(BlueprintCallable, Category = "Jetpack")
    void StartJetpack();

    UFUNCTION(BlueprintCallable, Category = "Jetpack")
    void StopJetpack();

    UFUNCTION(BlueprintPure, Category = "Jetpack")
    float GetCurrentFuelPercent() const;

protected:
    virtual void BeginPlay() override;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Jetpack Defaults")
    TSubclassOf<AJetpackBase> DefaultJetpackClass;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Jetpack Defaults")
    UJetpackDataAsset *DefaultJetpackData;

    UPROPERTY(EditDefaultsOnly, Category = "Setup")
    FName CharacterSocketName = "Spine_03"; // Standard mannequin bone

private:
    UPROPERTY()
    AJetpackBase *CurrentJetpackActor;
};