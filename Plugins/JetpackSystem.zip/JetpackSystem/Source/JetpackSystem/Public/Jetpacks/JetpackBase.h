#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "JetpackDataAsset.h"
#include "GameFramework/Character.h"
#include "JetpackBase.generated.h"

UCLASS(Abstract)
class JETPACKSYSTEM_API AJetpackBase : public AActor
{
    GENERATED_BODY()

public:
    AJetpackBase();

    virtual void Tick(float DeltaTime) override;

    // Initialize with owner and data
    virtual void InitializeJetpack(ACharacter *InOwnerChar, UJetpackDataAsset *InData);

    // Input hooks
    virtual void StartThrust();
    virtual void StopThrust();

protected:
    virtual void ConsumeFuel(float DeltaTime);
    virtual void ApplyThrust(float DeltaTime);

    // Hooks for VFX
    void ActivateVFX();
    void DeactivateVFX();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    UStaticMeshComponent *MeshComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    class UNiagaraComponent *NiagaraComponent;

    UPROPERTY(BlueprintReadOnly, Category = "State")
    ACharacter *OwningCharacter;

    UPROPERTY(BlueprintReadOnly, Category = "Config")
    UJetpackDataAsset *JetpackData;

    UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "State")
    float CurrentFuel;

    UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "State")
    bool bIsThrusting;

    UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "State")
    bool bIsDepleted;
};