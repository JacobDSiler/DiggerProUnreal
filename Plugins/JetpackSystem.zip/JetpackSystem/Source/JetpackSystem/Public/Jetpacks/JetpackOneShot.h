#pragma once
#include "CoreMinimal.h"
#include "Jetpacks/JetpackBase.h"
#include "JetpackOneShot.generated.h"

UCLASS()
class JETPACKSYSTEM_API AJetpackOneShot : public AJetpackBase
{
    GENERATED_BODY()

public:
    virtual void StartThrust() override;
    virtual void StopThrust() override;

protected:
    virtual void ApplyThrust(float DeltaTime) override;

private:
    float OriginalAirControl;
};