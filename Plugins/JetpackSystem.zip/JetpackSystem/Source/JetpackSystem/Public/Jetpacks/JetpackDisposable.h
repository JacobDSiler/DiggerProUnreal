#pragma once
#include "CoreMinimal.h"
#include "Jetpacks/JetpackBase.h"
#include "JetpackDisposable.generated.h"

UCLASS()
class JETPACKSYSTEM_API AJetpackDisposable : public AJetpackBase
{
    GENERATED_BODY()
    // Base class handles "bIsDepleted" logic which effectively kills this jetpack
    // We could add logic here to detach and drop the mesh physically when spent.
};