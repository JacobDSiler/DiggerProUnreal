#pragma once
#include "CoreMinimal.h"
#include "Jetpacks/JetpackBase.h"
#include "JetpackRefuelable.generated.h"

UCLASS()
class JETPACKSYSTEM_API AJetpackRefuelable : public AJetpackBase
{
    GENERATED_BODY()

protected:
    virtual void Tick(float DeltaTime) override;
    virtual void StopThrust() override;

private:
    float LastThrustTime;
};