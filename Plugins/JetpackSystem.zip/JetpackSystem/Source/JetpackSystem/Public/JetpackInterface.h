#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "JetpackInterface.generated.h"

UINTERFACE(MinimalAPI)
class UJetpackInterface : public UInterface
{
    GENERATED_BODY()
};

class JETPACKSYSTEM_API IJetpackInterface
{
    GENERATED_BODY()

public:
    // Returns the component responsible for jetpack logic
    virtual class UJetpackComponent *GetJetpackComponent() const = 0;
};