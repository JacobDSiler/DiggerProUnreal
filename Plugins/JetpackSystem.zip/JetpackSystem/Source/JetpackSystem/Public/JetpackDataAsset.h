#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "NiagaraSystem.h"
#include "JetpackDataAsset.generated.h"

UCLASS(BlueprintType)
class JETPACKSYSTEM_API UJetpackDataAsset : public UDataAsset
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Stats")
    float ThrustStrength = 1000.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Stats")
    float MaxFuel = 100.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Stats")
    float FuelConsumptionRate = 10.0f;

    // Used only for Refuelable types
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Stats|Refuel")
    float RefuelRate = 5.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Stats|Refuel")
    float RefuelDelay = 2.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "VFX")
    UNiagaraSystem *ExhaustVFX;
};